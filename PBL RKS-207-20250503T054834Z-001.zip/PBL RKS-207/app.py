from flask import Flask, request, jsonify
from flask_socketio import SocketIO, emit
import openai
import os

# Inisialisasi Flask dan Socket.IO
app = Flask(__name__)
app.config['SECRET_KEY'] = 'raptor_secret_key'  # Secret key untuk keamanan
socketio = SocketIO(app)  # Inisialisasi Socket.IO

# Set API key OpenAI
openai.api_key = os.getenv('OPENAI_API_KEY')  # Gunakan environment variable untuk API key

# Simpan data user (sementara)
users = {}

# Route untuk halaman utama
@app.route('/')
def index():
    return "Welcome to PurpleLink Simulator!"

# Route untuk registrasi user
@app.route('/register', methods=['POST'])
def register():
    data = request.json
    username = data.get('username')
    password = data.get('password')

    if username in users:
        return jsonify({'status': 'error', 'message': 'Username already exists'}), 400

    users[username] = password
    return jsonify({'status': 'success', 'message': 'User registered successfully'})

# Route untuk login user
@app.route('/login', methods=['POST'])
def login():
    data = request.json
    username = data.get('username')
    password = data.get('password')

    if username not in users or users[username] != password:
        return jsonify({'status': 'error', 'message': 'Invalid username or password'}), 401

    return jsonify({'status': 'success', 'message': 'Login successful'})

# Route untuk testing
@app.route('/test')
def test():
    return "This is a test route!"

# Fungsi untuk mengirim pesan ke ChatGPT
def chat_with_gpt(prompt):
    response = openai.ChatCompletion.create(
        model="gpt-3.5-turbo",  # Model yang digunakan
        messages=[
            {"role": "system", "content": "You are a helpful assistant."},
            {"role": "user", "content": prompt},
        ],
        max_tokens=150,  # Batasan jumlah token
    )
    return response['choices'][0]['message']['content']

# Socket.IO event untuk chatbot
@socketio.on('chatbot')
def handle_chatbot(data):
    user_message = data.get('message')
    print(f'Chatbot received: {user_message}')
    
    # Kirim pesan ke ChatGPT
    bot_message = chat_with_gpt(user_message)
    
    # Kirim balasan ke client
    emit('chatbot_response', {'message': bot_message})

# Jalankan server
if __name__ == '__main__':
    socketio.run(app, debug=True, host='0.0.0.0', port=5000)