from fastapi import FastAPI, Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from pydantic import BaseModel
from typing import List, Optional
import uuid
from datetime import datetime

app = FastAPI()

# Simpan data sementara (dalam produksi gunakan database)
users_db = {}
chats_db = {}
ai_responses = {
    "en": {
        "connect": "For connection issues: 1) Check your internet 2) Restart RAPTOR 3) Verify server status",
        "slow": "Performance optimization: 1) Clear cache 2) Close other apps 3) Update to latest version",
        "default": "I'll help with your technical issue. Could you provide more details?"
    },
    "id": {
        "connect": "Untuk masalah koneksi: 1) Periksa internet 2) Mulai ulang RAPTOR 3) Verifikasi status server",
        "slow": "Optimisasi performa: 1) Bersihkan cache 2) Tutup aplikasi lain 3) Perbarui ke versi terbaru",
        "default": "Saya akan bantu masalah teknis Anda. Bisakah Anda memberikan detail lebih?"
    }
}

# Model data
class User(BaseModel):
    username: str
    token: str

class Message(BaseModel):
    id: str
    sender: str
    content: str
    timestamp: str
    language: str = "en"

class Chat(BaseModel):
    id: str
    participants: List[str]
    messages: List[Message]

# Autentikasi sederhana
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="token")

def get_current_user(token: str = Depends(oauth2_scheme)):
    if token not in users_db:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid authentication credentials",
            headers={"WWW-Authenticate": "Bearer"},
        )
    return users_db[token]

# Endpoints
@app.post("/register_chat_user/")
async def register_chat_user(user: User):
    users_db[user.token] = user.username
    return {"message": "User registered for chat"}

@app.post("/chats/", response_model=Chat)
async def create_chat(participants: List[str], current_user: str = Depends(get_current_user)):
    if current_user not in participants:
        participants.append(current_user)
    
    chat_id = str(uuid.uuid4())
    chat = Chat(id=chat_id, participants=participants, messages=[])
    chats_db[chat_id] = chat.dict()
    return chat

@app.get("/chats/", response_model=List[Chat])
async def get_user_chats(current_user: str = Depends(get_current_user)):
    user_chats = [chat for chat in chats_db.values() if current_user in chat['participants']]
    return user_chats

@app.post("/chats/{chat_id}/messages/", response_model=Message)
async def send_message(
    chat_id: str,
    content: str,
    language: str = "en",
    current_user: str = Depends(get_current_user)
):
    # Send message to DeepSeek API
    deepseek_response = await send_to_deepseek(content, language)
    
    if chat_id not in chats_db:
        raise HTTPException(status_code=404, detail="Chat not found")
    
    if current_user not in chats_db[chat_id]['participants']:
        raise HTTPException(status_code=403, detail="Not a participant in this chat")
    
    message_id = str(uuid.uuid4())
    timestamp = datetime.now().isoformat()
    message = Message(
        id=message_id,
        sender=current_user,
        content=content,
        timestamp=timestamp,
        language=language
    )
    
    chats_db[chat_id]['messages'].append(message.dict())
    
    # Generate AI response if needed
    if "raptor-ai" in chats_db[chat_id]['participants']:
        ai_message = generate_ai_response(content, language)
        ai_msg_id = str(uuid.uuid4())
        ai_timestamp = datetime.now().isoformat()
        ai_msg = Message(
            id=ai_msg_id,
            sender="raptor-ai",
            content=ai_message,
            timestamp=ai_timestamp,
            language=language
        )
        chats_db[chat_id]['messages'].append(ai_msg.dict())
    
    return message

async def send_to_deepseek(message: str, language: str):
    import httpx
    url = "https://api.deepseek.com/v1/chat"
    headers = {
        "X-API-KEY": "sk-cffbec9eae3046f2baab166272b82d1c",
        "Content-Type": "application/json"
    }
    payload = {
        "message": message,
        "language": language
    }
    
    async with httpx.AsyncClient() as client:
        response = await client.post(url, headers=headers, json=payload)
        response_data = response.json()
        return response_data.get("response", "No response from DeepSeek")
async def send_message(
    chat_id: str,
    content: str,
    language: str = "en",
    current_user: str = Depends(get_current_user)
):
    if chat_id not in chats_db:
        raise HTTPException(status_code=404, detail="Chat not found")
    
    if current_user not in chats_db[chat_id]['participants']:
        raise HTTPException(status_code=403, detail="Not a participant in this chat")
    
    message_id = str(uuid.uuid4())
    timestamp = datetime.now().isoformat()
    message = Message(
        id=message_id,
        sender=current_user,
        content=content,
        timestamp=timestamp,
        language=language
    )
    
    chats_db[chat_id]['messages'].append(message.dict())
    
    # Generate AI response if needed
    if "raptor-ai" in chats_db[chat_id]['participants']:
        ai_message = generate_ai_response(content, language)
        ai_msg_id = str(uuid.uuid4())
        ai_timestamp = datetime.now().isoformat()
        ai_msg = Message(
            id=ai_msg_id,
            sender="raptor-ai",
            content=ai_message,
            timestamp=ai_timestamp,
            language=language
        )
        chats_db[chat_id]['messages'].append(ai_msg.dict())
    
    return message

@app.get("/chats/{chat_id}/messages/", response_model=List[Message])
async def get_messages(chat_id: str, current_user: str = Depends(get_current_user)):
    if chat_id not in chats_db:
        raise HTTPException(status_code=404, detail="Chat not found")
    
    if current_user not in chats_db[chat_id]['participants']:
        raise HTTPException(status_code=403, detail="Not a participant in this chat")
    
    return chats_db[chat_id]['messages']

def generate_ai_response(message: str, language: str = "en"):
    message_lower = message.lower()
    
    if "connect" in message_lower or "koneksi" in message_lower:
        return ai_responses[language]["connect"]
    elif "slow" in message_lower or "lambat" in message_lower:
        return ai_responses[language]["slow"]
    
    return ai_responses[language]["default"]