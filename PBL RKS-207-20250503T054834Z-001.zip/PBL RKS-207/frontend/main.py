from fastapi import FastAPI

app = FastAPI()

@app.get("/")
def read_root():
    return {"message": "Welcome to RAPTOR Chat API"}

@app.get("/test")
def test_endpoint():
    return {"status": "API is working!"}